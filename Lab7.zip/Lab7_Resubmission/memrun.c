#include <stdio.h>
#include <unistd.h>
#include <time.h>

#define RAND_MAX 32767

#define ARRAY_SIZE (3600*4096)
#define PAGE_SIZE 4096
#define WORKING_SET 720

char array[ARRAY_SIZE]={'0'};

void memrun(int a, int b)
{
	//char array[ARRAY_SIZE]={'0'};
	time_t start, end;
	printf("%d %d\n",a,b);
	int rand_index=0;
	int rand_pos;
	double dif=0.0;
	char temp;
	
	time (&start);
	time (&end);
	dif=difftime(end,start);
	printf("Access %d pages for %d seconds.\n",ARRAY_SIZE/PAGE_SIZE,a);
	while(dif < (double)a)
	{
		
		rand_index=rand() %(ARRAY_SIZE/PAGE_SIZE);
		rand_pos=rand()%PAGE_SIZE;
		temp = array[rand_index*PAGE_SIZE+rand_pos];

		time (&end);
		dif=difftime(end,start);
	}
	
	rand_index=0;
	time (&start);
	time (&end);
	dif=difftime(end,start);
	printf("Access %d pages for %d seconds.\n",WORKING_SET,b);
	while(dif < (double)b)
	{
		rand_index=rand()%WORKING_SET;
		rand_pos=rand()%PAGE_SIZE;
		temp = array[rand_index*PAGE_SIZE+rand_pos];
		
		time (&end);
		dif=difftime(end,start);
	}
	
	printf("The page size is %ld bytes.\n",
               sysconf(_SC_PAGESIZE));
}

int main(int argc, char **argv)
{
	int large_access=-1;
	int small_access=-1;
	srand(time(NULL));
	if (argc == 3)
	{
		large_access=-1;
		small_access=-1;
		sscanf(argv[1], "%d", &large_access);
		sscanf(argv[2], "%d", &small_access);
	}
	if (argc != 3  ||  large_access == -1 || small_access == -1)
	{
		fprintf(stderr, "Usage: %s [ sec_for_large_access(integer) ] [ sec_for_small_access(integer) ]\n", argv[0]);
		exit(-1);
	}
	while(1){
		memrun(large_access,small_access);
		}

	return 0;
  
}

#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
int main()
{
syscall(175);
return 0;
}

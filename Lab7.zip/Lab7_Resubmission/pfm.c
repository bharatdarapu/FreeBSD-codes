#include <stdlib.h>

int main()
{
	for(;;){
		system("clear");
		syscall(180,"");
		sleep(1);
	}
	return 0;

}

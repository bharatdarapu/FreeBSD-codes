#include <sys/param.h>
#include <sys/module.h>
#include <sys/kernel.h>
#include <sys/systm.h>
#include <sys/sysent.h>
#include <sys/lock.h>
#include <sys/mutex.h>
#include <sys/proc.h>
#include <sys/resource.h>
#include <sys/sx.h>
#include <sys/vmmeter.h>

#include <vm/vm.h>
#include <vm/vm_param.h>
#include <vm/vm_object.h>
#include <vm/vm_page.h>
#include <vm/vm_pager.h>
#include <vm/vm_extern.h>
#include <vm/swap_pager.h>
#include <vm/vm_map.h>


struct pfr_monitor_args{
};

struct perprocpf
{
        int proc_id,proc_pf,proc_pfr; // Process ID, Total number of page fault, Page fault rate
        char proc_state[5];          // Process Stat "running" or "waiting"
        char proc_cmd[20];            // Process Name
        long curr_res_m,total_vm;     //Currrent Resident Memory and Total size of VM
};

static int pfr_monitor(struct proc* p1,struct pfr_monitor_args* uap)
{
	    
	// Declare Required Variables Here
	int count=0, loopvariable, length=0;
	struct perprocpf tempstorage;
		
	struct proc *p;
    struct thread *td1;
    struct perprocpf entry[100];
	int m1,m2,m3,m4,m5;
	int a,b,swaptotal,swapused, swapratio;
	int tot_pf_lsec=0;
	int j;
	
	// Colleting all Process Specific information 
        sx_slock(&allproc_lock);
        FOREACH_PROC_IN_SYSTEM(p) {
                		// Get PID, Process Name, Total Number of page faults, Page fault rate, Total VM, Resident memory here
				// Implement logic to calculate total page faults in Last second
				if(count > 99) break;
				
				entry[count].proc_id = p->p_pid;
				entry[count].proc_pf = p->page_fault_count;
				
				//here we use the fact that this program is called every second by the user
				if(p->prev_page_fault_count != 0) {
					entry[count].proc_pfr = p->page_fault_count - p->prev_page_fault_count;
				} else {
					entry[count].proc_pfr = 0;	//only happens on first run
				}
				p->prev_page_fault_count = p->page_fault_count;
				tot_pf_lsec += entry[count].proc_pfr;
				
				strncpy(entry[count].proc_cmd, p->p_comm, 20);
                entry[count].curr_res_m = vmspace_resident_count(p->p_vmspace) * PAGE_SIZE/1024;
				entry[count].total_vm = p->p_vmspace->vm_map.size/1024;
				
				FOREACH_THREAD_IN_PROC(p, td1) {			
                       //Get the state of the process
					if((td1->td_state == TDS_CAN_RUN) || (td1->td_state == TDS_RUNQ) || (td1->td_state == TDS_RUNNING)) {
						strcpy(entry[count].proc_state, "RUN");
						break;
					} else {
						strcpy(entry[count].proc_state, "WAIT");
						break;
					}
                }
				count++;
        }
        sx_sunlock(&allproc_lock);
		length = count;
	
	// Sort perprocpf entry array according to page fault rate in descending order
	for(count=0; count<(length - 1); count++) {
		for(loopvariable=count+1; loopvariable<length; loopvariable++) {
			if(entry[count].proc_pfr < entry[loopvariable].proc_pfr) {
				tempstorage = entry[count];
				entry[count] = entry[loopvariable];
				entry[loopvariable] = tempstorage;
			}
		}
	}
	   
	// Display 
        uprintf("\nPID\tSTATE\tPF_PROC\t  PFR\t  CUR_RES\t   TOTAL_VM\tCMD\n");
        for(j=0;j<15;j++)
        {
		 uprintf("%d\t%s\t%d\t%4d\t%7luk\t%7luk\t%s\n",entry[j].proc_id,entry[j].proc_state,entry[j].proc_pf,entry[j].proc_pfr,entry[j].curr_res_m, entry[j].total_vm,entry[j].proc_cmd);
        }
        uprintf("Page faults in last sec: %d  Total page fault: %d\n",tot_pf_lsec,cnt.v_vm_faults);
        m1=cnt.v_active_count *PAGE_SIZE/1024 ;
        m2=cnt.v_inactive_count *PAGE_SIZE/1024;
        m3=cnt.v_wire_count *PAGE_SIZE/1024;
        m4=cnt.v_cache_count *PAGE_SIZE/1024;
        m5=cnt.v_free_count *PAGE_SIZE/1024;
        uprintf("Mem Usage>> Active:%dk Inactive:%dk Wired:%dk Cached:%dk Free:%dk\n",m1,m2,m3,m4,m5);
        swap_pager_status(&a, &b);
        swaptotal = a * PAGE_SIZE/1024;
        swapused = b * PAGE_SIZE/1024;
        if(swapused!=0)
                swapratio=swapused*100/swaptotal;
        else
                swapratio=0;
        uprintf("Swap Usage >> Total:%dk Used:%dk Ratio:%d%%",swaptotal,swapused,swapratio);

  	return(0);
}

static struct sysent pfr_monitor_sysent = {
	0,
	( sy_call_t *)pfr_monitor
};

static int syscall_num = NO_SYSCALL;

static int load_handler(struct module *m, int what, void *arg)
{
	int err = 0;
	switch(what) {
		case MOD_LOAD:
			uprintf("System call loaded at slot: %d\n",syscall_num);
			break;
		case MOD_UNLOAD:
			uprintf("System call unloaded from slot: %d\n",syscall_num);
			break;
		default:
			err = EINVAL;
			break;
	}
	return(err);
}

SYSCALL_MODULE(pfr_monitor,
		&syscall_num,
		&pfr_monitor_sysent,
		load_handler,
		NULL);




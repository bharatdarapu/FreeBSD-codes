#include<unistd.h>
#include<stdlib.h>

int main() {
	char ch[15] = "hello world!";
	printf("\n\n Executing ... \n\n");
	syscall(180,ch);
	printf("\n done");
	return 0;
}

#include<unistd.h>
#include<stdlib.h>

int main() {
	char ch[20] = "custom_interrupt";
	printf("\nAdding software interrupt with name %s", ch);
	if(syscall(180,ch)) {
		return 1;
	}
	printf("\nSuccessfully added software interrupt");
	printf("\nSchedulling newly added software interrupt %s to run", ch);
	syscall(175);
	printf("\nSchedulled Successfully\n");
	return 0;
}

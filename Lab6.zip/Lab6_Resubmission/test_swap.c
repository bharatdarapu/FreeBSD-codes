#define LARGE_NUM 0000000
int main()
{
const int size = LARGE_NUM;
long* test = (long*)malloc(size * sizeof(long));

unsigned int i=0,swap =0;

for(;i<size;i++)
test[i] = rand();

while(1)
{
int ind = rand()%size;
swap = test[ind];
test[ind] = test[0];
test[0]=swap;
}
return 0;
}

#include <sys/param.h>
#include <sys/module.h>
#include <sys/systm.h>
#include <sys/kernel.h>
#include <sys/sysent.h>
#include <sys/lock.h>
#include <sys/mutex.h>
#include <sys/proc.h>
#include <sys/resource.h>
#include <sys/sx.h>
#include <sys/vmmeter.h>
#include <vm/vm.h>
#include <vm/vm_param.h>
#include <vm/vm_object.h>
#include <vm/vm_page.h>
#include <vm/vm_pager.h>
#include <vm/vm_extern.h>
#include <vm/swap_pager.h>
#include <vm/vm_map.h>


/*code change for lab6 */

struct test_args{
};


struct proc_info
{
        int proc_id,proc_pf,proc_pfr; // process ID, page fault count, page fault rate
        char proc_state[5];           // state of the process
        char proc_cmd[20];            // name of the process
        long total_vm,curr_res_m;     // total vm size and currrent resident memory
};


/*syscall implementation*/
int test(struct thread *td,struct test_args* uap)
{
	
	int count=0, loopvariable, length=0;
	struct proc_info tempstorage;
	struct proc *p;
	struct thread *td1;
        struct proc_info entry[100];
	int mem1,mem2,mem3,mem4,mem5;
	int runproc=0,waitproc=0;
	int a,b,swap_t,swap_u, swap_r; //total swap space, swap spave used and swap ratio
	int tot_pf_lsec=0;
	int j;
	
	// Colleting all Process Specific information 
        sx_slock(&allproc_lock);
        FOREACH_PROC_IN_SYSTEM(p) {
                		// Get PID, Process Name, Total Number of page faults, Page fault rate, Total VM, Resident memory here
				// Implement logic to calculate total page faults in Last second
				if(count > 99) break;
				
				entry[count].proc_id = p->p_pid;
				entry[count].proc_pf = p->page_fault_count;
				
			
				if(p->prev_page_fault_count != 0) {
					entry[count].proc_pfr = p->page_fault_count - p->prev_page_fault_count;
				} else {
					entry[count].proc_pfr = 0;	
				}
				p->prev_page_fault_count = p->page_fault_count;
				tot_pf_lsec += entry[count].proc_pfr;
				
				strncpy(entry[count].proc_cmd, p->p_comm, 20);
                entry[count].curr_res_m = vmspace_resident_count(p->p_vmspace) * PAGE_SIZE/1024;
				entry[count].total_vm = p->p_vmspace->vm_map.size/1024;
				
				FOREACH_THREAD_IN_PROC(p, td1) {			
                       //process state
					if((td1->td_state == TDS_CAN_RUN) || (td1->td_state == TDS_RUNQ) || (td1->td_state == TDS_RUNNING)) {
						strcpy(entry[count].proc_state, "RUN");
						runproc++;
						break;
					} else {
						strcpy(entry[count].proc_state, "WAIT");
						waitproc++;
						break;
					}
                }
				count++;
        }
        sx_sunlock(&allproc_lock);
		length = count;
	
	// Sorting based on page fault rate in descending order
	for(count=0; count<(length - 1); count++) {
		for(loopvariable=count+1; loopvariable<length; loopvariable++) {
			if(entry[count].proc_pfr < entry[loopvariable].proc_pfr) {
				tempstorage = entry[count];
				entry[count] = entry[loopvariable];
				entry[loopvariable] = tempstorage;
			}
		}
	}
	   


	// Display 
        uprintf("\nPID\tSTATE\tPF_PROC\tPFR\tPFVS\tCUR_RES\tTOTAL_VM\tRATIO\tCMD\n");
        for(j=0;j<15;j++)
        {
	//int pfvs = (entry[j].proc_pfr*100) /cnt.v_vm_faults;
	//int ratio = (entry[j].curr_res_m * 100) / entry[j].total_vm;
	int pfvs = 0;
	int ratio = 0;
		 uprintf("%d\t%s\t%d\t%4d\t%d\t%7luk\t%7luk\t%d\t%s\n",entry[j].proc_id,entry[j].proc_state,entry[j].proc_pf,entry[j].proc_pfr,pfvs,entry[j].curr_res_m, entry[j].total_vm,ratio,entry[j].proc_cmd);
        }
        uprintf("Page faults in last sec: %d  Total page fault: %d\n",tot_pf_lsec,cnt.v_vm_faults);
        mem1=cnt.v_active_count *PAGE_SIZE/1024 ;
        mem2=cnt.v_inactive_count *PAGE_SIZE/1024;
        mem3=cnt.v_wire_count *PAGE_SIZE/1024;
        mem4=cnt.v_cache_count *PAGE_SIZE/1024;
        mem5=cnt.v_free_count *PAGE_SIZE/1024;
	uprintf("Total Processes: %d, Running :%d, Waiting: %d\n",runproc+waitproc,runproc,waitproc);
        uprintf("Mem Usage>> Active:%dk Inactive:%dk Wired:%dk Cached:%dk Free:%dk\n",mem1,mem2,mem3,mem4,mem5);
        swap_pager_status(&a, &b);
        swap_t = a * PAGE_SIZE/1024;
        swap_u = b * PAGE_SIZE/1024;
        if(swap_u!=0)
                swap_r=swap_u*100/swap_t;
        else
                swap_r=0;
        uprintf("Swap Usage >> Total:%dk Used:%dk Ratio:%d%%",swap_t,swap_u,swap_r);

  	return(0);
}

static struct sysent test_sysent = {
	0,
	( sy_call_t *)test
};

static int syscall_num = NO_SYSCALL;

static int load_handler(struct module *m, int what, void *arg)
{
	int err = 0;
	switch(what) {
		case MOD_LOAD:
			uprintf("System call loaded at slot: %d\n",syscall_num);
			break;
		case MOD_UNLOAD:
			uprintf("System call unloaded from slot: %d\n",syscall_num);
			break;
		default:
			err = EINVAL;
			break;
	}
	return(err);
}

SYSCALL_MODULE(test,
		&syscall_num,
		&test_sysent,
		load_handler,
		NULL);



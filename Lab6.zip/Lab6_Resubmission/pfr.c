#include <stdio.h>
#include <stdlib.h>
#include <sys/syscall.h>
int main()
{
	while(1)
	{
		system("clear");
		syscall(175);
		sleep(1);
	}
	return 0;
}

ReadMe file for Lab 3 Make up

Files Edited:
kern/kern_switch.c
kern/kern_synch.c
kern/sched_4bsd.c

Lab Tasks: placed CTR statements in respective funcitons to understand the working of mmi_switch

1. Kernel calls machine independent switcher mi_switch() to do context switch

mi_switch funciton is declared at Line 456 in kern/kern_synch.c
CTR4 call was declared at line 469 inside the mi_switch functoin to show that it is called

2. mi_switch() calls actual scheduler switcher
mi_switch calls the sched_4bsd which is the actual scheduler funciton sched_switch(td) at line 530.
CTR call was declared at line 485 to log the sched_switch call.

3. Scheduler sets the current thread to a proper run queue
kern_switch.c was modified at line 327 under function setrunqueue()
CTR4 call was made to log this.

4. Add the KSE of current thread to a run queue
In kern_switch.c file,under the function setrunqueue()
A CTR call is made before sched_add to log this.

5. Scheduler finds a thread with the highest priority (td_priority) to run.
At line 618 the scheduler find the thread with highest priority by making the call to choosethread() function.
A CTR call was made in line 619 to log this.

6. Remove the KSE of the chosen thread from the run queues
kern_switch.c was modified at line 606 under function runq_remove()
A CTR call was made in line 614 to log this.

7. Kernel calls machine dependent switcher to have the chosen thread running on CPU (log the information of chosen thread only)
At line 620, the switcher is called by making the call to cpu_switch

8. Exit mi_switch()
mi_switch exists by line 628. A CTR call was just before that to log.

Task2
1. Kernel calls schedcpu()
sched_4bsd.c was modified at line 270 under function schedcpu(), CTR call was made.	

2. Find a timesharing thread needs adjustment in run queue
kern_switch.c was modified at line 289 under function adjustrunqueue(),CTR call was made.

3. Finish adjusting the run queue of a timesharing thread
kern_switch.c was modified at line 316 under function adjustrunqueue(),CTR call was made.

4. Exit schedcpu()
sched_4bsd.c was modified and I added the below code at line 348 under function schedcpu(),CTR call was made.
